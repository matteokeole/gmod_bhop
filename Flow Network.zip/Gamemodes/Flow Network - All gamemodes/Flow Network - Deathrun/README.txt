This gamemode requires more setting up than any of the other gamemodes in the release, since this gamemode is NOT finished yet.
It's operational, almost fully, since we were about to release it. There's a bug in it however, and I can't figure out what it is, but the server crashes when you're alone in the server and die as an Undead runner because of trigger damage.

This gamemode does not come with the customization and will require some Lua editing.
I hope someone will be able to get this ready and online, since you'll be the first person with a Deathrun gamemode that has a timer aspect to it.

It's basically default Deathrun, but with most of my Bunny Hop core still in it.
Good luck setting it up! I'll come visit myself if you do ;)

Thank you and enjoy it!
Gravious