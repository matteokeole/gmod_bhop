function ENT:Initialize() end
function ENT:Think() end
function ENT:Draw() end