-- Strafe Retards WJ Fix

__HOOK[ "InitPostEntity" ] = function()
	Zones.StepSize = 16
end