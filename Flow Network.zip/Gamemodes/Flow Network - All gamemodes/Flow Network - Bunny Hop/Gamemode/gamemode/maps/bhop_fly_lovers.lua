-- Fly Lovers +left allowing

__HOOK[ "InitPostEntity" ] = function()
	Timer:SetLeftBypass( true )
end