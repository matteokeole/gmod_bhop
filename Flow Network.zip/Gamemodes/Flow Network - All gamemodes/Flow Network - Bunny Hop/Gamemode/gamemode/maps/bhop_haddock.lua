-- Haddock Bonus Step Size

__HOOK[ "InitPostEntity" ] = function()
	Zones.BonusStepSize = 16
	Zones.DefaultStepSize = 18
end