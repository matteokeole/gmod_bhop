The files in these folders are REQUIRED to have working SINGLE HOP maps, working boosters, and working fixes for maps such as 'bhop_fury' or 'bhop_aoki_final'

Paste them in your /garrysmod/ base folder, so the files in lua/autorun will also go to your lua/autorun folder.