I went on vacation and wanted to try something out.
Made this by changing some small things.

All you have to do, I believe, is to navigate to your GarrysMod installation path, open /gamemodes/ and put it in a new folder called "bhop".
To then play it (I've only done this once or so, but uhh), open your game and on the bottom left select "Bunny Hop" - This will also give you a prettier logo, so you might want to keep it on at all times.
After you've selected the gamemode and you can see the logo, simply start a map as you would via Singleplayer and it should work!