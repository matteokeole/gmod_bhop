Please do not redistribute any of the works in this release under a different name.
Feel free to use it anywhere you want.

I decided to add a LICENSE.txt file that shows what you can do with it without harming my emotions.
I don't want to be restrictive at all since this is a public release, but I despise people using other people's work under their name.

Thank you very much for having read my thread and eventually for downloading this file.

Kind regards,
Gravious